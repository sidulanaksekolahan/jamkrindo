package dev.satkomindo.base.spring.configuration;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "pusatEntityManagerFactory", transactionManagerRef = "pusatTransactionManager", basePackages = { "dev.satkomindo.base.spring.pusat.repositories" })
public class DatabasePusatConfig {
	@Bean(name = "pusatDataSource")
	@ConfigurationProperties(prefix = "spring.pusat")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}

	@Bean(name = "pusatEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean pusatEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("pusatDataSource") DataSource dataSource) {
		return builder.dataSource(dataSource).packages("dev.satkomindo.base.spring.pusat").persistenceUnit("pusat").build();
	}

	@Bean(name = "pusatTransactionManager")
	public PlatformTransactionManager pusatTransactionManager(
			@Qualifier("pusatEntityManagerFactory") EntityManagerFactory pusatEntityManagerFactory) {
		return new JpaTransactionManager(pusatEntityManagerFactory);
	}
}

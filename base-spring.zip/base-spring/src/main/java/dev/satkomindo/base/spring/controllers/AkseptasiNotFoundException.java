package dev.satkomindo.base.spring.controllers;

public class AkseptasiNotFoundException extends RuntimeException {

	public AkseptasiNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public AkseptasiNotFoundException(String message) {
		super(message);
	}

	public AkseptasiNotFoundException(Throwable cause) {
		super(cause);
	}	

}

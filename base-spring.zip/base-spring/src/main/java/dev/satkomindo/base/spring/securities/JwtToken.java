package dev.satkomindo.base.spring.securities;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;


import java.io.Serializable;
import java.security.Key;
import io.jsonwebtoken.*;

import java.util.Date;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


public class JwtToken implements Serializable {
	
	private static final long serialVersionUID = -2550185165626007488L;

	// Sample method to construct a JWT
	protected String createJWT(String id, String issuer, String subject, long ttlMillis, String[] scope) {

		// The JWT signature algorithm we will be using to sign the token
		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS512;

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);

		// We will sign our JWT with our ApiKey secret
		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary("t3t4mb42019");
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

		// Let's set the JWT Claims
		Claims claims = Jwts.claims().setSubject("jamkrindo-core");
        claims.put("scope", scope);
        
		JwtBuilder builder = Jwts.builder()
				.setId(id)
				.setClaims(claims)
				.setIssuedAt(now)
				.setSubject(subject)
				.setIssuer(issuer)
				.signWith(signatureAlgorithm, signingKey);

		// if it has been specified, let's add the expiration
		if (ttlMillis >= 0) {
			long expMillis = nowMillis + ttlMillis;
			Date exp = new Date(expMillis);
			builder.setExpiration(exp);
		}

		// Builds the JWT and serializes it to a compact, URL-safe string
		return builder.compact();
	}

	protected Claims parseJWT(String jwt, String base64SecretBytes) {

		// This line will throw an exception if it is not a signed JWS (as expected)
		Claims claims = Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(base64SecretBytes))
				.parseClaimsJws(jwt).getBody();
		System.out.println("ID: " + claims.getId());
		System.out.println("Subject: " + claims.getSubject());
		System.out.println("Issuer: " + claims.getIssuer());
		System.out.println("Expiration: " + claims.getExpiration());

		return claims;
	}

}

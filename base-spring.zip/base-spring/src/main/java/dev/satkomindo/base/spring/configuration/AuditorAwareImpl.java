package dev.satkomindo.base.spring.configuration;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;

public class AuditorAwareImpl implements AuditorAware<String> {

	@Override
	public Optional<String> getCurrentAuditor() {
		// Can use Spring Security to return currently logged in user
		String name = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
		if(name != null) {
			return Optional.of(name);
		} else {
			return Optional.of("0");
		}
		
	}

}

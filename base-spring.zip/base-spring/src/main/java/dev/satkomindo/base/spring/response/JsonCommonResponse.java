package dev.satkomindo.base.spring.response;

import java.io.Serializable;

import lombok.Data;

@Data
public class JsonCommonResponse<T> implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2824929455860865680L;
	
	private String success;
	private String message;
	private String data;

}

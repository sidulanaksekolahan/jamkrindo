package dev.satkomindo.base.spring.response;

import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class AkseptasiResponse<T> {
	
	private String success;
	private String message;
	private List<T> data;

}

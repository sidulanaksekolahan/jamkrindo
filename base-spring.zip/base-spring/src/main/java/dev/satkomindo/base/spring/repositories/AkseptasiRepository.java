package dev.satkomindo.base.spring.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import dev.satkomindo.base.spring.models.Akseptasi;

@Repository
public interface AkseptasiRepository extends JpaRepository<Akseptasi, String> {
	
	@Query("select a from Akseptasi a where a.namaDebitur=?1")
	public List<Akseptasi> findAllByName(String namaDebitur);

}

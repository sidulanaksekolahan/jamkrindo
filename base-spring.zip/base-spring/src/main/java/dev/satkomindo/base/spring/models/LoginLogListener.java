package dev.satkomindo.base.spring.models;

import java.util.Optional;

import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;

public class LoginLogListener implements AuditorAware<String> {

	static final Logger LOGGER = LoggerFactory.getLogger(LoginLogListener.class);

	@PrePersist
	void onPrePersist(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPrePersist() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostPersist
	void onPostPersist(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostPersist() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostLoad
	void onPostLoad(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostPersist() : " + loginLog + " by user_id " + getCurrentAuditor().get());

	}

	@PreUpdate
	void onPreUpdate(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPreUpdate() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostUpdate
	void onPostUpdate(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostUpdate() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PreRemove
	void onPreRemove(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPreRemove() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostRemove
	void onPostRemove(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostRemove() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@Override
	public Optional<String> getCurrentAuditor() {
		// TODO Auto-generated method stub
		// Can use Spring Security to return currently logged in user
		String name = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
		if (name != null) {
			return Optional.of(name);
		} else {
			return Optional.of("0");
		}
	}
}

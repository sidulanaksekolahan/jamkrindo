package dev.satkomindo.base.spring.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dev.satkomindo.base.spring.models.Akseptasi;
import dev.satkomindo.base.spring.repositories.AkseptasiRepository;

@Service
public class AkseptasiServiceImpl implements AkseptasiService {
	
	private AkseptasiRepository akseptasiRepository;
	
	@Autowired
	public AkseptasiServiceImpl(AkseptasiRepository theAkseptasiRepository) {
		this.akseptasiRepository = theAkseptasiRepository;
	}

	@Override
	public List<Akseptasi> findAll() {
		return akseptasiRepository.findAll();
	}

	@Override
	public List<Akseptasi> findAllByName(String namaDebitur) {
		return akseptasiRepository.findAllByName(namaDebitur);
	}

}

package dev.satkomindo.base.spring.services;

import java.util.List;

import dev.satkomindo.base.spring.models.Akseptasi;

public interface AkseptasiService {
	
	public List<Akseptasi> findAll();
	public List<Akseptasi> findAllByName(String namaDebitur);
//	public void save(Akseptasi theAkseptasi);

}

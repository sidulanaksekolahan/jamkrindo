package dev.satkomindo.base.spring.exceptions;

import java.util.HashMap;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import dev.satkomindo.base.spring.response.LoginResponse;

@ControllerAdvice
public class SecurityExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({AccessDeniedException.class})
    @ResponseBody
    public HashMap<String, Object> handleAccessDeniedException(Exception ex, WebRequest request) {
        if(ex.getMessage().toLowerCase().indexOf("access is denied") > -1) {
        	return (HashMap<String, Object>) LoginResponse.setupBase(false, "Anda tidak punya privilege untuk API ini.", null);
        }

        return (HashMap<String, Object>) LoginResponse.setupBase(false, ex.getMessage(), null);
    }
}

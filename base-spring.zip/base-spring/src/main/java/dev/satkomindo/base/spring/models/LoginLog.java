package dev.satkomindo.base.spring.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import dev.satkomindo.base.spring.configuration.Auditable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "login_log")
@EntityListeners(LoginLogListener.class)
@JsonIgnoreProperties(value = { "createdAt", "updatedAt" }, allowGetters = true)
public class LoginLog extends Auditable<String> implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8870972326404276208L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_login_log")
	private Integer idLoginLog;

	@Column(name = "user_id")
	private Integer userId;

	@Column(name = "message")
	private String message;

	@Column(name = "ip_address")
	private String ipAddress;
}

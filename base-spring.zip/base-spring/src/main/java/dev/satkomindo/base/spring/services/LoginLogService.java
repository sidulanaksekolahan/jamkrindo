package dev.satkomindo.base.spring.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dev.satkomindo.base.spring.models.LoginLog;
import dev.satkomindo.base.spring.repositories.LoginLogRepository;

@Service
public class LoginLogService {
	@Autowired
	private LoginLogRepository repo;
	
	public LoginLog findByIdLoginLog(Integer id) {
		return repo.findByIdLoginLog(id);
	}
	
	public String saveLogging(Integer userId, String message, String ipAddress) {
		LoginLog entity = new LoginLog();
		entity.setIpAddress(ipAddress);
		entity.setMessage(message);
		entity.setUserId(userId);
		if(repo.save(entity) != null) {
			return "success";
		} else {

			return "fail";
		}
	}
}

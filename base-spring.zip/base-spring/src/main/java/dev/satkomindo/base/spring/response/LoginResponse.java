package dev.satkomindo.base.spring.response;

import java.util.LinkedHashMap;
import java.util.Map;

public class LoginResponse {

	public static Map<String, Object> setupBase(Boolean success, String message, String data) {
        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("success", success);
        resp.put("message", message);
        resp.put("data", data);

        return resp;
    }
}

package dev.satkomindo.base.spring.models;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name="akseptasi")
public class Akseptasi {
	
	@Id
	@Column(name="no_rekening")
	private String noRekening;
	
	@Column(name="nama_debitur")
	private String namaDebitur;
	
	@Column(name="alamat_debitur")
	private String alamatDebitur;
	
	@Column(name="ktp")
	private String ktp;
	
	@Column(name="tgl_lahir")
	private LocalDate tglLahir;
	
	@Column(name="jk")
	private String jk;
	
	@Column(name="produk")
	private String produk;
	
	@Column(name="kode_cabang")
	private String kodeCabang;
	
	@Column(name="kode_bank")
	private String kodeBank;
	
	@Column(name="nama_cabang")
	private String namaCabang;
	
	@Column(name="kode_pekerjaan")
	private String kodePekerjaan;
	
	@Column(name="nama_pekerjaan")
	private String namaPekerjaan;
	
	@Column(name="no_pk")
	private String noPk;
	
	@Column(name="tgl_pk")
	private LocalDate tglPk;
	
	@Column(name="plafond")
	private Float plafond;
	
	@Column(name="tenor")
	private int tenor;
	
	@Column(name="tgl_pertanggungan")
	private LocalDate tglPertanggungan;
	
	@Column(name="tgl_pertanggungan_jatuh_tempo")
	private LocalDate tglPertanggunganJatuh_tempo;
	
	@Column(name="alamat_agunan")
	private String alamatAgunan;
	
	@Column(name="tipe_pertanggungan")
	private String tipePertanggungan;
	
	@Column(name="nilai_taksasi")
	private Float nilaiTaksasi;
	
	@Column(name="premi")
	private Float premi;
	
	@Column(name="fee_based")
	private Float feeBased;
	
	@Column(name="pajak_fee")
	private Float pajakFee;
	
	@Column(name="fee_based_net")
	private Float feeBasedNet;
	
	@Column(name="premi_net")
	private Float premiNet;
	
	@Column(name="outstanding")
	private Float outstanding;
	
	@Column(name="status")
	private String status;
	
	@Column(name="keterangan_status")
	private String keteranganStatus;
	
	@Column(name="nomor_va")
	private String nomorVa;
	
	@Column(name="created_at")
	private LocalDateTime createdAt;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="updated_at")
	private LocalDateTime updatedAt;
	
	@Column(name="updated_by")
	private String updatedBy;
	
	@Column(name="lock")
	private Integer lock;		
}

package dev.satkomindo.base.spring.controllers;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import dev.satkomindo.base.spring.models.LoginLog;
import dev.satkomindo.base.spring.repositories.LoginLogRepository;
import dev.satkomindo.base.spring.services.LoginLogService;


@RestController
@RequestMapping("/api")
@Component
public class TestController {
	
	@Autowired
	private LoginLogService serviceLog;
	
	@Autowired
	private LoginLogRepository repo;
	
	static final Logger LOGGER = LoggerFactory.getLogger(TestController.class);
	@PostMapping(value = "/v1/test")
	@PreAuthorize("hasAuthority('category') and hasAuthority('user')")
	@ResponseBody
	public String test(HttpServletRequest httpRequest) {
		serviceLog.saveLogging(0, "User ID tidak ditemukan di SSO Jamkrindo.", httpRequest.getLocalAddr());
		LOGGER.info("inilah cara membuat log");
		return "test";
	}
	
	@PostMapping(value = "/v1/login")
	@ResponseBody
	public String test1(HttpServletRequest httpRequest) throws InterruptedException {
		serviceLog.saveLogging(0, "User ID tidak ditemukan di SSO Jamkrindo.", httpRequest.getLocalAddr());
		
		Thread.sleep(10000);
		LoginLog test = serviceLog.findByIdLoginLog(8);
		if(test != null) {
			test.setMessage("updated message");
			repo.save(test);
		}
		
		LoginLog delete = serviceLog.findByIdLoginLog(28);
		if(delete != null) {
			repo.delete(delete);
		}
				
		LOGGER.info("inilah cara membuat log");
		return "test";
	}
}

# Berikut beberapa hal yang harus dikonfigurasi setelah melakukan clone :
<dl>
    <dt>- Edit auth-service\src\main\resources\application.properties</dt>
        <dd>Edit spring.application.name=`base-spring` menjadi nama service yang kalian kerjakan</dd>
        <dd>Edit contextPath menjadi server.servlet.contextPath=`/`</dd>
</dl>

#
<dl>
    <dt>- base-spring\src\main\java\dev\satkomindo\base\spring\configuration\DatabaseMainConfig.java</dt>
</dl>

```
@EnableJpaRepositories(
  entityManagerFactoryRef = "entityManagerFactory",
  basePackages = { "dev.satkomindo.base.spring.repositories" }
)
```
```
@Primary
	@Bean(name = "entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("dataSource") DataSource dataSource) {
		return builder
				.dataSource(dataSource)
				.packages("dev.satkomindo.base.spring")
				.persistenceUnit("main")
				.build();
	}
```
<dl>
    <dd>Edit `base.spring` dengan nama service yang kalian buat</dd>
    <dd>base-spring\src\main\java\dev\satkomindo\base\spring\configuration\DatabasePengajuanConfig.java</dd>
</dl>

```
@EnableJpaRepositories(entityManagerFactoryRef = "pengajuanEntityManagerFactory", transactionManagerRef = "pengajuanTransactionManager", basePackages = { "dev.satkomindo.base.spring.repositories" })
```
```
@Bean(name = "pengajuanEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean pusatEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("pengajuanDataSource") DataSource dataSource) {
		return builder.dataSource(dataSource).packages("dev.satkomindo.base.spring.pengajuan").persistenceUnit("pengajuan").build();
	}
```

<dl>
    <dd>Edit `base.spring` dengan nama service yang kalian buat</dd>
    <dd>base-spring\src\main\java\dev\satkomindo\base\spring\configuration\DatabasePusatConfig.java</dd>
</dl>

```
@EnableJpaRepositories(entityManagerFactoryRef = "pusatEntityManagerFactory", transactionManagerRef = "pusatTransactionManager", basePackages = { "dev.satkomindo.base.spring.pusat.repositories" })
```

```
@Bean(name = "pusatEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean pusatEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("pusatDataSource") DataSource dataSource) {
		return builder.dataSource(dataSource).packages("dev.satkomindo.base.spring.pusat").persistenceUnit("pusat").build();
	}
```

<dl>
    <dd>Edit `base.spring` dengan nama service yang kalian buat</dd>
</dl>

#

<dl>
    <dt>- Edit auth-service\pom.xml</dt>
</dl>

```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
	<modelVersion>4.0.0</modelVersion>
	<parent>
		<groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-parent</artifactId>
		<version>2.2.4.RELEASE</version>
		<relativePath /> <!-- lookup parent from repository -->
	</parent>
	<groupId>dev.satkomindo</groupId>
	<artifactId>auth-service</artifactId>
	<version>0.0.1-SNAPSHOT</version>
	<packaging>war</packaging>
	<name>auth-service</name>
	<description>Service Auth Login return JWT</description>
```

<dl>
    <dd>Edit `auth-service` dengan nama service yang kalian buat</dd>
</dl>


    
# Audit Trail dan Logging ke log file pada Spring Boot 2.2.4

<dl>
    <dt>- Audit Trail pada Spring Boot</dt>
    <dd>Siapkan di table kalian beberapa field seperti di bawah : </dd>
</dl>    
        
| nama_field | type_data |
| ---------- | --------- |
| created_at | datetime NULL |
| created_by | varchar(255) NULL |
| updated_at | datetime NULL |
| updated_by | varchar(255) NULL |

    
<dl>
    <dd>Lalu extends class Auditable<String> dan implements Serializable seperti contoh dibawah ini, untuk serialVersionUID bisa kalian generate :</dd>
</dl>
        
```   
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @ToString
    @Entity
    @Table(name = "login_log")
    @EntityListeners(LoginLogListener.class)
    @JsonIgnoreProperties(value = { "createdAt", "updatedAt" }, allowGetters = true)
    public class LoginLog extends Auditable<String> implements Serializable {
    	/**
    	 * 
    	 */
    	private static final long serialVersionUID = -8870972326404276208L;
    
    	@Id
    	@GeneratedValue(strategy = GenerationType.IDENTITY)
    	@Column(name = "id_login_log")
    	private Integer idLoginLog;
    
    	@Column(name = "user_id")
    	private Integer userId;
    
    	@Column(name = "message")
    	private String message;
    
    	@Column(name = "ip_address")
    	private String ipAddress;
    }
```

#

<dl>
    <dt>- Logging semua activity yang terjadi pada suatu table</dt>
    <dd>Siapkan class listener seperti dibawah ini contoh untuk table login_log :</dd>
</dl>

```
import java.util.Optional;

import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContextHolder;

public class LoginLogListener implements AuditorAware<String> {

	static final Logger LOGGER = LoggerFactory.getLogger(LoginLogListener.class);

	@PrePersist
	void onPrePersist(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPrePersist() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostPersist
	void onPostPersist(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostPersist() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostLoad
	void onPostLoad(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostPersist() : " + loginLog + " by user_id " + getCurrentAuditor().get());

	}

	@PreUpdate
	void onPreUpdate(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPreUpdate() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostUpdate
	void onPostUpdate(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostUpdate() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PreRemove
	void onPreRemove(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPreRemove() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@PostRemove
	void onPostRemove(LoginLog loginLog) {
		LOGGER.info("LoginLog.onPostRemove() : " + loginLog + " by user_id " + getCurrentAuditor().get());
	}

	@Override
	public Optional<String> getCurrentAuditor() {
		// TODO Auto-generated method stub
		// Can use Spring Security to return currently logged in user
		String name = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
		if (name != null) {
			return Optional.of(name);
		} else {
			return Optional.of("0");
		}
	}
}

```

<dl>
    <dd>Lalu tambahkan <b>@EntityListeners(LoginLogListener.class)</b> pada models <b>LoginLog</b> class dan jangan lupa untuk menambahkan @<b>ToString</b>, seperti di bawah ini :</dd>
</dl>

```
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name = "login_log")
@EntityListeners(LoginLogListener.class)
@JsonIgnoreProperties(value = { "createdAt", "updatedAt" }, allowGetters = true)
public class LoginLog extends Auditable<String> implements Serializable {
....
}
```

<dl>
    <dd>Di atas merupakan contoh logging dan audit trail automatic selanjutnya logging secara manual</dd>
</dl>

#

<dl>
    <dt>- Logging secara manual menggunakan logback.xml dan slf4j</dt>
    <dd>Konfigurasi logging ada pada file <b>logback.xml</b> seperti dibawah ini :</dd>
</dl>

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xml>
<configuration>

	<appender name="STDOUT"
		class="ch.qos.logback.core.ConsoleAppender">
		<!-- encoders are assigned the type ch.qos.logback.classic.encoder.PatternLayoutEncoder 
			by default -->
		<encoder>
			<pattern>%d{dd/MM/yyyy HH:mm:ss.SSS} [%-20.20thread] %-5level %-25.25logger{25} - %msg%n</pattern>
		</encoder>
	</appender>

	<appender name="FILE"
		class="ch.qos.logback.core.rolling.RollingFileAppender">
		<file>${catalina.home}/logs/webapp.log</file>
		<rollingPolicy
			class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
			<!-- daily rollover -->
			<fileNamePattern>${catalina.home}/logs/webapp.%d{yyyy-MM-dd}.%i.log</fileNamePattern>
			<!-- each file should be at most 20MB, keep 90 days worth of history, but at most 20GB -->
			<maxFileSize>20MB</maxFileSize>    
       		<maxHistory>90</maxHistory>
      		<totalSizeCap>20GB</totalSizeCap>
		</rollingPolicy>
		<encoder>
			<pattern>%d{dd/MM/yyyy HH:mm:ss.SSS} [%thread] %-5level %logger{36} -
				%msg%n</pattern>
		</encoder>
	</appender>

	<logger name="org.displaytag" level="WARN" />
	<logger name="org.hibernate" level="WARN" />
	<logger name="org.springframework" level="WARN" />
	<logger name="org.springframework.web" level="DEBUG" />
	<logger name="org.zalando.logbook" level="TRACE" />
	<logger name="org.springframework.web.filter.CommonsRequestLoggingFilter" level="DEBUG" />
	<logger name="org.apache.http" level="DEBUG" />
	<root level="info">
		<appender-ref ref="STDOUT" />
		<appender-ref ref="FILE" />
	</root>
</configuration>
```

<dl>
    <dd>Cara mendeklarasikan log dengan cara seperti di bawah ini : </dd>
</dl>

```
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import dev.satkomindo.base.spring.models.LoginLog;
import dev.satkomindo.base.spring.repositories.LoginLogRepository;
import dev.satkomindo.base.spring.services.LoginLogService;


@RestController
@RequestMapping("/api")
@Component
public class TestController {
	
	@Autowired
	private LoginLogService serviceLog;
	
	@Autowired
	private LoginLogRepository repo;
	
	static final Logger LOGGER = LoggerFactory.getLogger(TestController.class);
	@PostMapping(value = "/v1/test")
	@PreAuthorize("hasAuthority('category') and hasAuthority('user')")
	@ResponseBody
	public String test(HttpServletRequest httpRequest) {
		serviceLog.saveLogging(0, "User ID tidak ditemukan di SSO Jamkrindo.", httpRequest.getLocalAddr());
		LOGGER.info("inilah cara membuat log");
		return "test";
	}
	
	@PostMapping(value = "/v1/login")
	@ResponseBody
	public String test1(HttpServletRequest httpRequest) throws InterruptedException {
		serviceLog.saveLogging(0, "User ID tidak ditemukan di SSO Jamkrindo.", httpRequest.getLocalAddr());
		
		Thread.sleep(10000);
		LoginLog test = serviceLog.findByIdLoginLog(8);
		if(test != null) {
			test.setMessage("updated message");
			repo.save(test);
		}
		
		LoginLog delete = serviceLog.findByIdLoginLog(28);
		if(delete != null) {
			repo.delete(delete);
		}
				
		LOGGER.info("inilah cara membuat log");
		return "test";
	}
}
```

<dl>
    <dd>Tambahkan kode ini <b>static final Logger LOGGER = LoggerFactory.getLogger(TestController.class);</b> TestController.class bisa diganti dengan class yang kalian ingin log</dd>
    <dd>Tambahkan kode ini <b>LOGGER.info("inilah cara membuat log");</b></dd>
</dl>